package br.com.uol.pagseguro.api.exception;

public class PagSeguroClientException {

}
